class PCB:
    """
    Process Control Block: A class to store the information of a process.
    To simplify the process, I assume the arrival time is a Integer, and the execution time is a Integer.
    """

    def __init__(self, pid: str, arrival_time: int, execution_time: int):
        self.pid: str = pid
        self.arrival_time: int = arrival_time
        self.execution_time: int = execution_time

        self.start_time: int = -1  # -1 means the process has not started yet

        # init
        self.time_execution_spent: int = 0
        self.completed_time: int = -1  # -1 means the process has not been completed yet

        self.waiting_time: int = 0

    def get_remaining_time(self) -> int:
        return self.execution_time - self.time_execution_spent

    def get_waiting_time(self) -> int:
        return self.get_turnaround_time() - self.time_execution_spent

    def get_turnaround_time(self) -> int:
        return self.completed_time - self.arrival_time

    def get_response_time(self) -> int:
        return self.start_time - self.arrival_time
