from process_manage import ProcessManageSystem


def main():
    manage_system = ProcessManageSystem()
    manage_system.run()


if __name__ == "__main__":
    main()
