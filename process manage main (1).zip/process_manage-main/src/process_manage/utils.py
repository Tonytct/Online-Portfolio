from typing import List


def to_format_string_list(num_list: List[float]) -> List[str]:
    new_list = [f"{num:.2f}" for num in num_list]
    return new_list
