from typing import List
from enum import Enum
import prettytable as pt

from process import PCB
from utils import to_format_string_list


class Algorithm(Enum):
    FCFS = 1
    SJF = 2
    RR = 3
    STCF = 4


class ProcessManageSystem:
    """
    To simplify the process, I assume the system is a single-core system.
    """

    def __init__(self):
        self.dead_queue: List[
            PCB
        ] = []  # store the process that has been completed, to print the result
        self.waiting_queue: List[
            PCB
        ] = []  # store the process that is waiting to be selected
        self.process_num: int = 0  # how many processes in total
        self.current_time: int = 0
        self.running_process: PCB | None = None
        self.busy_time: int = 0  # the time the CPU has been used

    def run(self):
        self.process_num = int(
            input("Input the number of processes you need to manage: ")
        )

        # input the information of the processes with lines
        print()
        print("#####Input process information#####")
        print("format: <pid> <arrival_time> <execution_time>\n")
        for i in range(self.process_num):
            pid, arrival_time, execution_time = map(int, input().split())
            new_process: PCB = PCB(pid, arrival_time, execution_time)
            self.add_process(new_process)

        print("The processes have been added successfully!\n")

        print("########Algorithm########")
        for algo in Algorithm:
            print(f"{algo.value}.{algo.name}")

        print()
        algorithm: Algorithm = Algorithm(
            int(input("Input the algorithm you want to use: "))
        )

        if algorithm == Algorithm.FCFS:
            self.FCFS()
        elif algorithm == Algorithm.SJF:
            self.SJF()
        elif algorithm == Algorithm.RR:
            self.RR()
        elif algorithm == Algorithm.STCF:
            self.STCF()

        self.print_result()

    def add_process(self, process: PCB) -> None:
        self.waiting_queue.append(process)

    def FCFS(self) -> None:
        # sort the waiting queue by the arrival time
        self.waiting_queue.sort(key=lambda x: x.arrival_time)

        while self.waiting_queue or self.running_process:
            if self.running_process is not None:
                self.run_time(1)
            else:
                if self.current_time >= self.waiting_queue[0].arrival_time:
                    self.running_process = self.waiting_queue.pop(0)
                else:
                    self.run_time(1)

    def run_time(self, time: int) -> None:
        """
        run the process for a certain time, if there is no process running, just update the current time

        if the process has been completed, move it to the dead queue, set running process to None

        :param time: the time to run the process
        """
        # if there is no process running, just update the current time
        # to push the time forward

        # for debug
        # print(
        #     f"current time: {self.current_time}, running process: {self.running_process.pid if self.running_process else None}, waiting queue: {[process.pid for process in self.waiting_queue]}"
        # )

        if self.running_process is None:
            self.current_time += time
            return

        ########## run the process ##########

        # if first time to run the process, init the start time
        if self.running_process.start_time == -1:
            self.running_process.start_time = self.current_time

        # update the time spent on execution
        self.running_process.time_execution_spent += time
        self.update_waiting_time(time)
        self.current_time += time
        self.busy_time += time

        # if the process has been completed, move it to the dead queue
        if (
            self.running_process.time_execution_spent
            >= self.running_process.execution_time
        ):
            self.running_process.completed_time = self.current_time
            self.dead_queue.append(self.running_process)
            self.running_process = None

    def update_waiting_time(self, time) -> None:
        """
        update the waiting time of the processes in the waiting queue
        """
        for process in self.waiting_queue:
            if self.current_time >= process.arrival_time:
                process.waiting_time += time

    def SJF(self) -> None:
        while self.waiting_queue or self.running_process:
            if self.running_process is not None:
                self.run_time(1)
            else:
                process = self.select_process_SJF()
                if process:
                    self.running_process = process
                    self.waiting_queue.remove(process)
                else:
                    self.run_time(1)

    def RR(self) -> None:
        # sort the waiting queue by the arrival time
        self.waiting_queue.sort(key=lambda x: x.arrival_time)

        while self.waiting_queue or self.running_process:
            if self.running_process is not None:
                self.run_time(1)
                self.push_running_process_end_RR_STCF()

            else:
                process = self.waiting_queue[0]
                if process.arrival_time <= self.current_time:
                    self.running_process = self.waiting_queue.pop(0)
                else:
                    self.run_time(1)

    # push back to the correct position in RR
    def push_running_process_end_RR_STCF(self) -> None:
        """
        push the process back to the waiting queue in the correct position

        if the process is None, do nothing

        just push the process back to the end of the true waiting queue(the process's arrival time <= current time)

        this function is not perfect, due to the class design, because we push all the PCB into the waiting queue at the beginning
        """
        process = self.running_process

        if process is None:
            return

        new_waiting_queue: List[PCB] = []
        index = len(self.waiting_queue)
        for i, p in enumerate(self.waiting_queue):
            if p.arrival_time <= self.current_time:
                new_waiting_queue.append(p)
            else:
                index = i
                break

        new_waiting_queue.append(process)
        new_waiting_queue.extend(self.waiting_queue[index:])

        self.waiting_queue = new_waiting_queue
        self.running_process = None

    def STCF(self) -> None:
        """
        Shortest Time-to-Completion First (STCF) Scheduling Algorithm

        This is a preemptive version of SJF.
        """
        while self.waiting_queue or self.running_process:
            # if there is a running process
            if self.running_process is not None:
                # run the process for 1 unit time
                self.run_time(1)
                self.update_shortest_remaining_to_running()
            else:
                # if there is no running process
                next_process = self.select_process_STCF()
                if next_process:
                    self.running_process = next_process
                    self.waiting_queue.remove(next_process)
                else:
                    # if there is no process to run
                    self.run_time(1)

    def update_shortest_remaining_to_running(self) -> None:
        """
        STCF scheduling algorithm

        update the process with the shortest remaining execution time as the running process
        """
        shortest_remaining_process = self.select_process_STCF()
        if shortest_remaining_process is None:
            return

        if self.running_process is None:
            self.running_process = shortest_remaining_process
            self.waiting_queue.remove(shortest_remaining_process)
            return

        if (
            self.running_process.get_remaining_time()
            < shortest_remaining_process.get_remaining_time()
        ):
            return

        if (
            self.running_process.get_remaining_time()
            >= shortest_remaining_process.get_remaining_time()
        ):
            self.waiting_queue.remove(shortest_remaining_process)
            self.push_running_process_end_RR_STCF()
            self.running_process = shortest_remaining_process

    def select_process_STCF(self) -> PCB | None:
        """
        select the process with the shortest remaining execution time
        """
        # 按剩余执行时间排序
        arrival_processes: List[PCB] = [
            process
            for process in self.waiting_queue
            if process.arrival_time <= self.current_time
        ]
        arrival_processes.sort(key=lambda x: x.get_remaining_time())
        return arrival_processes[0] if arrival_processes else None

    def select_process_SJF(self) -> PCB | None:
        """
        find the process with the shortest execution time in the waiting queue,
        the process's arrival time should be less than the current time
        """
        # sort the waiting queue by the execution time
        self.waiting_queue.sort(key=lambda x: x.execution_time)
        for process in self.waiting_queue:
            if process.arrival_time <= self.current_time:
                return process
        return None

    def print_result(self):
        process_result_tb = pt.PrettyTable()
        process_result_tb.title = "Process Result"

        process_result_tb.field_names = [
            "Process ID",
            "Arrival Time",
            "Execution Time",
            "Response Time",
            "Completed Time",
            "Waiting Time",
            "Turnaround Time",
        ]

        for process in self.dead_queue:
            process_result_tb.add_row(
                [
                    process.pid,
                    process.arrival_time,
                    process.execution_time,
                    process.get_response_time(),
                    process.completed_time,
                    process.get_waiting_time(),
                    process.get_turnaround_time(),
                ]
            )

        print()
        print(process_result_tb)

        avg_tb = pt.PrettyTable()
        avg_tb.title = "Average Result"
        avg_tb.field_names = [
            "Average Waiting Time",
            "Average Turnaround Time",
            "CPU Utilization",
        ]
        avg_waiting_time = sum(
            [process.get_waiting_time() for process in self.dead_queue]
        ) / len(self.dead_queue)
        avg_turnaround_time = sum(
            [
                process.completed_time - process.arrival_time
                for process in self.dead_queue
            ]
        ) / len(self.dead_queue)
        cpu_utilization = self.busy_time / self.current_time
        avg_tb.add_row(
            to_format_string_list(
                [avg_waiting_time, avg_turnaround_time, cpu_utilization]
            )
        )
        print()
        print(avg_tb)
        print()
