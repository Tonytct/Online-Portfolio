# Process Management

## Usage

this project use uv to manage python environment, so you need to install uv first.

## 1. Install uv

use the following command to install uv.

```bash
# On macOS and Linux.
curl -LsSf https://astral.sh/uv/install.sh | sh

# On Windows.
powershell -c "irm https://astral.sh/uv/install.ps1 | iex"

# With pip.
pip install uv
```

## 2. Install dependencies

after install uv, you can use the following command to install dependencies.

```bash
git clone https://github.com/Kelfvin/process_manage
cd process_manage
```

then use uv to install dependencies.

```bash
uv sync
```

the uv make sure that your python environment is same as the developer's.

## 3. Run the project

after install dependencies, you can use the following command to run the project.

```bash
uv run src/process_manage/main.py
```

the process will ask you to input the PCB information, you need to input the PCB information in the following format.

```plaintext
1 0 8
2 2 4
3 4 1
```

the first number is the process id, the second number is the arrival time, the third number is the burst time.
